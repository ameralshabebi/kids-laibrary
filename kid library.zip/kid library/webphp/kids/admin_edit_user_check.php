<?php include 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
// if there is post from the user to edit the profile
if (isset ( $_POST ['submit'] )) {
	$age = $_POST ['age'];
	$mobile = $_POST ['mobile'];
	$name = $_POST ['name'];
	$password = $_POST ['password'];
	$email = $_POST ['email'];
	$id = $_POST ['id'];
	
	$update_query = "UPDATE user
								SET age = $age, mobile = '$mobile', name = '$name', password = '$password', email = '$email'
								WHERE id = $id";
	
	$update_user_result = mysqli_query($conn,  $update_query ) or die ( "Can't update this user" . mysql_error () );
	
	// if there is affected rows in the database;
	if (mysqli_affected_rows ($conn) == 1) {
		// set the session var for the user
		$_SESSION ['user'] = $name;
		
		echo "<h3>Thank you for edit the user profile ....</h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3;url=admin_show_users.php">';
	} else {
		echo "<h3>No update Happend in the user profile data .... </h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3;url=admin_show_users.php">';
	}
} // end if isset($_POST['edit_profile'])

else { // if there is no post to edit the profile; show the reset of the page
       // check for the user is login or not
       // if he not logged in ; redirect to the index page
	if (! isset ( $_SESSION ['user'] ) || $_SESSION ['user'] == "") {
		echo '<meta http-equiv="refresh" content="3;url=index.php">';
	}
}
?>

<?php include 'footer.php'; ?>