<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "publisher") {
	header ( "Location: index.php" );
}
?>

<?php
$categories = mysqli_query ( $conn, "SELECT * FROM catalog" );
?>

<h2>Add New Book</h2>

<p>&nbsp;</p>

<div class="row">
	<div
		class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-default">
			<div class="panel-body">
				<form name="my_form" role="form"
					action="publisher_add_book_check.php" method="post"
					enctype="multipart/form-data">
					<fieldset>
						<div class="form-group">
							<strong>ISBN</strong> <input type="text" name="isbn"
								class="form-control" required pattern="\d{9}|\d{13}"
								title="enter valid isbn just 9 or 13 numbers">

						</div>
						<div class="form-group">
							<strong>Title</strong> <input type="text" name="title"
								class="form-control" required
								title="enter valid title just letters">
						</div>
						<div class="form-group">
							<strong>Author</strong> <input type="text" name="author"
								class="form-control" required
								title="enter valid author just letters">
						</div>
						<div class="form-group">
							<strong>Pages</strong> <input type="number" name="pages"
								class="form-control" required min="1">
						</div>
						<div class="form-group">
							<strong>Age</strong> <input type="number" name="age"
								class="form-control" required min="1" max="12">
						</div>
						<div class="form-group">
							<strong>Category</strong> <select name="cat_id"
								class="form-control">
				<?php while ($category = mysqli_fetch_array($categories)) {?>
					<option value="<?php echo $category['id']?>"><?php echo $category['title']?></option>
				<?php }?>
				</select>
						</div>
						<div class="form-group">
							<strong>File</strong> <input type="file" name="file"
								class="form-control" required />
						</div>
						<div align="center">
							<input type="submit" name="submit" class="btn btn-primary"
								value="Add" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.col-->
</div>
<?php include 'footer.php';?>