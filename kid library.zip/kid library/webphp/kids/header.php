<?php include 'server_connect.php';?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>==> Kids Books System ==<</title>

<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/datepicker3.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">

<!--Icons-->
<script src="js/lumino.glyphs.js"></script>

<style>
table {
	background-color: #fff;
	border: 1px solid #ccc;
}

th, td {
	padding: 10px;
	text-align: center;
}
</style>

</head>

<body>
	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed"
					data-toggle="collapse" data-target="#sidebar-collapse">
					<span class="sr-only">Toggle navigation</span> <span
						class="icon-bar"></span> <span class="icon-bar"></span> <span
						class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php"><span>Kids Books</span>System</a>
				<ul class="user-menu">
					<li class="dropdown pull-right"><a href="#" class="dropdown-toggle"
						data-toggle="dropdown"><svg class="glyph stroked male-user">
								<use xlink:href="#stroked-male-user"></use></svg> <?php echo $_SESSION['user_name'];?> <span
							class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
						<?php if ($_SESSION ['user_id'] == "") { ?>
							<li><a href="login.php"><svg class="glyph stroked male-user">
										<use xlink:href="#stroked-male-user"></use></svg> Login</a></li>
							<li><a href="register.php"><svg class="glyph stroked male-user">
										<use xlink:href="#stroked-male-user"></use></svg> Register</a></li>
							<?php } else {?>
							<li><a href="logout.php"><svg class="glyph stroked cancel">
										<use xlink:href="#stroked-cancel"></use></svg> Logout</a></li>
							<!-- 							<li><a href="profile.php"><svg class="glyph stroked cancel"><use xlink:href="#stroked-cancel"></use></svg> Profile</a></li> -->
						<?php }?>
							
						</ul></li>
				</ul>
			</div>

		</div>
		<!-- /.container-fluid -->
	</nav>

	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">

		<ul class="nav menu">
		<?php if ($_SESSION ['user_type'] == "admin") {?>
				<li><a href="admin_show_users.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Manage Users</a></li>
			<li><a href="admin_show_publishers.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Manage Publishers</a></li>
			<li><a href="admin_show_catalogs.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Manage Catalogs</a></li>
			<li><a href="admin_show_books.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Manage Books</a></li>
				<?php } else if ($_SESSION ['user_type'] == "publisher") { ?>
				<li><a href="publisher_add_book.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Add New Book</a></li>
			<li><a href="publisher_show_books.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Manage Books</a></li>
			<li><a href="publisher_edit_profile.php#content"><svg
						class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Account</a></li>
				<?php } ?>
			
			<?php if ($_SESSION ['user_id'] != "") { ?>
			
			<li><a href="logout.php"><svg class="glyph stroked dashboard-dial">
						<use xlink:href="#stroked-dashboard-dial"></use>
					</svg> Logout</a></li>
			<?php } ?>
			
<!-- 				<li><a href="logout.php#content">Logout</a></li> -->
				
			<?php if ($_SESSION ['user_id'] == "") { ?>
			<li><a href="login.php"><svg class="glyph stroked male-user"> <use
							xlink:href="#stroked-male-user"></use></svg> Login</a></li>
			<li><a href="register.php"><svg class="glyph stroked male-user"> <use
							xlink:href="#stroked-male-user"></use></svg> Register</a></li>
				<?php }?>
		</ul>

	</div>
	<!--/.sidebar-->

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">