<?php include 'header.php';?>

<style>
td {
	text-align: center;
	padding: 5px;
}

th {
	background-color: #eee;
	padding: 10px;
}

</style>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "publisher") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<h2>Your Books</h2>
<?php
// get all information for the books
$books_query = "SELECT book.*, book.id AS book_id, catalog.title AS cat_title FROM book LEFT JOIN catalog ON catalog.id = book.cat_id WHERE book.publisher_id = $_SESSION[user_id]";

$books_result = mysqli_query($conn,  $books_query ) or die ( 'error : ' . mysql_error () );
?>
<div class="post">
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<th>ISBN</th>
			<th>Title</th>
			<th>Author</th>
			<th>Pages</th>
			<th>Catalog</th>
			<th>Age</th>
			<th>Action</th>
		</tr>
		<?php while ($book_row = mysqli_fetch_array($books_result)) { ?>
		<tr>
			<td><?php echo $book_row['isbn']?></td>
			<td><?php echo $book_row['title'];?></td>
			<td><?php echo $book_row['author']?></td>
			<td><?php echo $book_row['pages'];?></td>
			<td><?php echo $book_row['cat_title'];?></td>
			<td><?php echo $book_row['age'];?></td>
			<td>
				<a href="#" onclick="if(window.confirm('Are You sure to delete the book ?')) window.location='publisher_delete_book.php?isbn=<?php echo $book_row['isbn']?>'">Delete</a> | 
				<a href="books/<?php echo $book_row['file'];?>" target="_blank">PDF
					File</a> | <a href="books/<?php echo $book_row['file_audio'];?>"
				target="_blank">Audio File</a>
			</td>
		</tr>
		<?php }?>
		<tr>
			<th colspan="8"><a href="publisher_add_book.php">Add New Book</a></th>
		</tr>
	</table>
</div>
<?php include 'footer.php';?>