<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
// delete the catalog
mysqli_query($conn,  "DELETE FROM catalog WHERE id = $_GET[id]" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysqli_affected_rows ($conn) == 1) {
	echo "<h3>catalog Has been deleted successfuly ....</h3>";
	
	// redirect to the details page for the added book with the last inserted id
	echo '<meta http-equiv="refresh" content="3;url=admin_show_catalogs.php">';
} else {
	echo "<h2>There is an error in deleting catalog</h2>";
	echo '<meta http-equiv="refresh" content="3;url=admin_show_catalogs.php">';
}
?>

<?php include 'footer.php';?>