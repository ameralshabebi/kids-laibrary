<?php include 'header.php'; ?>

<h2>Edit User Profile</h2>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
// if the user is loggedin
$query = "SELECT * FROM user WHERE id = $_GET[id]";
$user_result = mysqli_query ( $conn, $query ) or die ( "can't run query because " . mysql_error () );

$user_row = mysqli_fetch_array ( $user_result );

if (mysqli_num_rows ( $user_result ) == 1) {
	?>
<p>&nbsp;</p>

<div class="row">
	<div
		class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-default">
			<div class="panel-body">
				<form name="my_form" role="form" action="admin_edit_user_check.php"
					method="post">
					<fieldset>
						<input type="hidden" name="id" value="<?php echo $_GET['id']?>" />
						<div class="form-group">
							<strong>Age</strong> <input type="number" name="age" min="1"
								max="12" value="<?php echo $user_row['age'];?>"
								class="form-control" required>
						</div>
						<div class="form-group">
							<strong>mobile</strong> <input type="text" name="mobile"
								value="<?php echo $user_row['mobile'];?>" class="form-control"
								required>
						</div>
						<div class="form-group">
							<strong>User Name</strong> <input type="text" name="name"
								value="<?php echo $user_row['name'];?>" class="form-control"
								required>
						</div>
						<div class="form-group">
							<strong>Email</strong> <input type="text" name="email"
								value="<?php echo $user_row['email'];?>" class="form-control">
						</div>
						<div class="form-group">
							<strong>Password</strong> <input type="password" name="password"
								value="<?php echo $user_row['password'];?>" class="form-control"
								required>
						</div>
						<div align="center">
							<input type="submit" name="submit" class="btn btn-primary"
								value="Update" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.col-->
</div>
<!-- /.row -->
<?php
} // end of else; the user didn't loggedin
?>

<?php include 'footer.php'; ?>