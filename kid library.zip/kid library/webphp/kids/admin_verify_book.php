<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<?php
// delete the student
mysqli_query ( $conn, "UPDATE book SET status = 'Verified' WHERE isbn = $_GET[isbn]" ) or die ( 'error verified' . mysqli_error ( $conn ) );

// if there is affected rows in the database;
if (mysqli_affected_rows ( $conn ) == 1) {
	echo "<h3>Book Has been Verified successfuly ....</h3>";
	
	// redirect to the details page for the added book with the last inserted id
	echo '<meta http-equiv="refresh" content="3;url=admin_show_books.php">';
} else {
	echo "<h2>There is an error in Verifing book</h2>";
	echo '<meta http-equiv="refresh" content="3;url=admin_show_books.php">';
}
?>

<?php include 'footer.php';?>