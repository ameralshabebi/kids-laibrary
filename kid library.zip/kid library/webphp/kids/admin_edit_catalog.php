<?php include 'header.php'; ?>

<h2>Edit Catalog</h2>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
$query = "SELECT * FROM catalog WHERE id = $_GET[id]";
$catalog_result = mysqli_query ( $conn, $query ) or die ( "can't run query because " . mysql_error () );

$catalog_row = mysqli_fetch_array ( $catalog_result );

if (mysqli_num_rows ( $catalog_result ) == 1) {
	?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<div class="row">
	<div
		class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-default">
			<div class="panel-heading">Edit Catlaog</div>
			<div class="panel-body">
				<form name="my_form" role="form"
					action="admin_edit_catalog_check.php" method="post">
					<fieldset>
						<input type="hidden" name="id" value="<?php echo $_GET['id']?>">
						<div class="form-group">
							<strong>Title</strong> <input type="text" name="title"
								class="form-control" value="<?php echo $catalog_row['title'];?>"
								required>
						</div>
						<div align="center">
							<input type="submit" name="submit" class="btn btn-primary"
								value="Update" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.col-->
</div>
<!-- /.row -->
<?php
} // end of else; the catalog didn't loggedin
?>

<?php include 'footer.php'; ?>