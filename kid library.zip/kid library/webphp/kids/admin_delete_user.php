<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
mysqli_query ( $conn, "DELETE FROM user WHERE id = $_GET[id]" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysqli_affected_rows ( $conn ) == 1) {
	echo "<h3>User Has been deleted successfuly ....</h3>";
	
	echo '<meta http-equiv="refresh" content="3;url=admin_show_users.php">';
} else {
	echo "<h2>There is an error in deleting user</h2>";
	echo '<meta http-equiv="refresh" content="3;url=admin_show_users.php">';
}
?>

<?php include 'footer.php';?>