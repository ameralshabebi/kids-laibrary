<?php include 'header.php';?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<?php
// get all information for the publishers
$publishers_query = "SELECT * FROM publisher";
$publishers_result = mysqli_query($conn,  $publishers_query ) or die ( 'error : ' . mysql_error () );
?>

<h2>All Publishers</h2>
<div class="post">
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Mobile</th>
			<th>District</th>
			<th>City</th>
			<th>Street</th>
			<th>Action</th>
		</tr>
		<?php while ($publisher_row = mysqli_fetch_array($publishers_result)) { ?>
		<tr style="text-align: center;">
			<td><?php echo $publisher_row['name'];?></td>
			<td><?php echo $publisher_row['email'];?></td>
			<td><?php echo $publisher_row['mobile'];?></td>
			<td><?php echo $publisher_row['district'];?></td>
			<td><?php echo $publisher_row['city'];?></td>
			<td><?php echo $publisher_row['street'];?></td>
			<td><a
				href="admin_edit_publisher.php?id=<?php echo $publisher_row['id']?>">Edit</a>
				 | <a href="#"
				onclick="if(window.confirm('Are You sure to delete the publisher ?')) window.location='admin_delete_publisher.php?id=<?php echo $publisher_row['id']?>'">Delete</a>
			</td>
		</tr>
		<?php }?>
		<tr>
			<th colspan="8" style="text-align: center;"><a
				href="admin_add_publisher.php">Add New publisher</a></th>
		</tr>
	</table>
</div>
<?php include 'footer.php';?>