<?php include 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "publisher") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
// if there is post from the publisher to edit the profile
if (isset ( $_POST ['submit'] )) {
	$mobile = $_POST ['mobile'];
	$name = $_POST ['name'];
	$password = $_POST ['password'];
	$email = $_POST ['email'];
	$id = $_SESSION ['user_id'];
	$district = $_POST ['district'];
	$city = $_POST ['city'];
	$street = $_POST ['street'];
	
	$update_query = "UPDATE publisher
								SET district = '$district', mobile = '$mobile', name = '$name', password = '$password', email = '$email', city = '$city', street = '$street' 
								WHERE id = $id";
	
	$update_publisher_result = mysqli_query($conn,  $update_query ) or die ( "Can't update this publisher" . mysql_error () );
	
	// if there is affected rows in the database;
	if (mysqli_affected_rows ($conn) == 1) {
		// set the session var for the publisher
		$_SESSION ['publisher'] = $name;
		
		echo "<h3>Thank you for edit the  profile ....</h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3;url=publisher_edit_profile.php">';
	} else {
		echo "<h3>No update Happend in the  profile data .... </h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3;url=publisher_edit_profile.php">';
	}
} // end if isset($_POST['edit_profile'])

else { // if there is no post to edit the profile; show the reset of the page
       // check for the publisher is login or not
       // if he not logged in ; redirect to the index page
	if (! isset ( $_SESSION ['user'] ) || $_SESSION ['user'] == "") {
		echo '<meta http-equiv="refresh" content="3;url=index.php">';
	}
}
?>

<?php include 'footer.php'; ?>