<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
if (isset ( $_POST ['submit'] )) {
	$age = $_POST ['age'];
	$mobile = $_POST ['mobile'];
	$name = $_POST ['name'];
	$password = $_POST ['password'];
	$email = $_POST ['email'];
	
	// query to check if the user has registerd before or not
	$name_query = mysqli_query($conn,  "SELECT name FROM user WHERE name = '$name' OR email = '$email'" ) or die ( 'error ' . mysql_error () );
	
	if (mysqli_num_rows ( $name_query ) != 0) {
		echo "<h3 style='text-align: center; padding-bottom: 10px; border-bottom: 1px solid #d9db5c'>This name or email has already registered before.... try another one</h3>";
		header ( "REFRESH:3; url=admin_add_user.php" );
	} else {
		// insert query for user
		$query = "INSERT INTO user
		(age, mobile, name, password, email)
		VALUES
		($age, '$mobile', '$name', '$password', '$email')";
		
		$user_result = mysqli_query($conn,  $query ) or die ( "Can't add this user" . mysql_error () );
		
		// if there is affected rows in the database;
		if (mysqli_affected_rows ($conn) == 1) {
			echo "<h3>You have add user successfuly</h3>";
			
			// redirect to the home page
			echo '<meta http-equiv="refresh" content="3;url=admin_show_users.php">';
		} else {
			echo "<h3>error in adding user </h3>";
			
			// redirect to the home page
			echo '<meta http-equiv="refresh" content="3;url=admin_show_users.php">';
		}
	}
}
?>

<?php include 'footer.php';?>