<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<div class="row">
	<div
		class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-default">
			<div class="panel-heading">Add New Catlaog</div>
			<div class="panel-body">
				<form name="my_form" role="form"
					action="admin_add_catalog_check.php" method="post">
					<fieldset>
						<div class="form-group">
							<strong>Title</strong> <input class="form-control"
								placeholder="Title" name="title" type="text" required>
						</div>
						<div align="center">
							<input type="submit" name="submit" class="btn btn-primary"
								value="Add" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.col-->
</div>
<!-- /.row -->
<?php include 'footer.php';?>