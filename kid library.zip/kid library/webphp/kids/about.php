<?php include 'header.php';?>

<h1>Kids Books System Designed By :-</h1>

<p align="justify">
	<table width="70%">
		<tr>
			<th></th>
			<td></td>
		</tr>
		
		<tr>
			<th></th>
			<td></td>
		</tr>
	</table>
</p>
<?php include 'footer.php';?>