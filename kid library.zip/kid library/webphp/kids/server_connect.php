<?php
// server vars
$server = "localhost";
$user = "root";
$password = "";
$database = "kids";

// connect to the server
$conn = mysqli_connect ( $server, $user, $password, $database ) or die ( "Sorry can't connect to the server" );

// select the database
// mysql_select_db ( $database ) or die ( "Sorry can't find this database" );

// satart the session var
session_start ();

// to remove all notice messages
error_reporting ( 'E-All ~E-Notice' );
?>