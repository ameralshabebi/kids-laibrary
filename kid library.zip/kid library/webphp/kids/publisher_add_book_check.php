﻿<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "publisher") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
if (isset ( $_POST ['submit'] )) {
	// books vars
	$isbn = $_POST ['isbn'];
	$title = $_POST ['title'];
	$author = $_POST ['author'];
	$cat_id = $_POST ['cat_id'];
	$age = $_POST ['age'];
	$pages = $_POST ['pages'];
	$file = $_FILES ["file"] ["name"];
	
	// echo $_FILES ["file"] ["type"];
	
	// check if the book is uploaded once before
	$book = mysqli_query ( $conn, "SELECT * FROM book WHERE isbn = '$isbn'" );
	if (mysqli_num_rows ( $book ) == 1) {
		echo "<h2>Sorry this book is uploaded before.... try another one</h2>";
		echo '<meta http-equiv="refresh" content="3;url=publisher_add_book.php">';
	} else {
		// script for upload file
		// check for book (pdf)
		// and size less than 5 mb
		if (($_FILES ['file'] ['type'] == "application/pdf") && ($_FILES ["file"] ["size"] < 5000000)) {
			// if there is an error in upload files
			if ($_FILES ["file"] ["error"] > 0) {
				echo "Error: " . $_FILES ["file"] ["error"] . "<br>";
			} else // there is no errors in uploading files
{
				move_uploaded_file ( $_FILES ["file"] ["tmp_name"], "books/" . $_FILES ["file"] ["name"] );
				
				$insert_query = "INSERT INTO book (isbn, title, author, age, file, cat_id, pages, publisher_id) VALUES ('$isbn', '$title', '$author', '$age', '$file', $cat_id, $pages, $_SESSION[user_id])";
				
				// echo $insert_query;
				
				$insert_book_result = mysqli_query ( $conn, $insert_query ) or die ( "Can't add this book" . mysql_error () );
				
				// if there is affected rows in the database;
				if (mysqli_affected_rows ( $conn ) == 1) {
					echo "<h3>Thank you for add the book ....</h3>";
					echo '<meta http-equiv="refresh" content="3;url=publisher_show_books.php">';
				} else {
					echo "<h3>cann't add this book ....</h3>";
					echo '<meta http-equiv="refresh" content="3;url=publisher_show_books.php">';
				}
			} // end else (there is no errors in uploading file)
		} // end if (check file types)
else // if the file type is not image; redirect to the add_book.php page
{
			echo "Invalid file";
			// header("REFRESH:2; url=add_book.php");
		} // end else ( if the file type is invalid )
	}
} // end if isset($_POST['add_book'])
else { // if there is no post to add book ; show the reset of the page
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php include 'footer.php';?>