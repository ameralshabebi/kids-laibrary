<?php include 'header.php';?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<?php
$catalogs_query = "SELECT * FROM catalog";
$catalogs_result = mysqli_query($conn,  $catalogs_query ) or die ( 'error : ' . mysql_error () );
?>

<h2>All catalogs</h2>
<div class="post">
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<th>ID</th>
			<th>Title</th>
			<th>Action</th>
		</tr>
		<?php while ($catalog_row = mysqli_fetch_array($catalogs_result)) { ?>
		<tr  style="text-align: center;">
			<td><?php echo $catalog_row['id']?></td>
			<td><?php echo $catalog_row['title'];?></td>
			<td><a href="admin_edit_catalog.php?id=<?php echo $catalog_row['id']?>">Edit</a>
				&nbsp;&nbsp;&nbsp;&nbsp; <a href="#" onclick="if(window.confirm('Are You sure to delete the catalog ?')) window.location='admin_delete_catalog.php?id=<?php echo $catalog_row['id']?>'">Delete</a>
			</td>
		</tr>
		<?php }?>
		<tr>
			<th colspan="5" style="text-align: center;"><a href="admin_add_catalog.php">Add New catalog</a></th>
		</tr>
	</table>
</div>
<?php include 'footer.php';?>