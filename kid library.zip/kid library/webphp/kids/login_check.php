<?php include 'header.php';?>

<?php
// if the user is logged in; redirect to the home page
if (isset ( $_SESSION ['user'] ) || $_SESSION ['user'] != "") {
	header ( "Location: index.php" );
} else {
	if (isset ( $_POST ['email'] ) && isset ( $_POST ['password'] )) {
		$email = $_POST ['email'];
		$password = $_POST ['password'];
		
		$query = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
		
		$member_result = mysqli_query ( $conn, $query ) or die ( "cant get email and password from the user" . mysqli_error($conn) );
		$member_row = mysqli_fetch_array ( $member_result );
		
		// if we find the email
		if (mysqli_num_rows ( $member_result ) == 1) {
			// set the session var for the user
			$_SESSION ['user'] = "admin";
			$_SESSION ['user_id'] = $member_row ['id']; // this is for get the user_id
			$_SESSION ['user_type'] = "admin"; // this is for get the user type
			
			echo '<h2>Thank you for login in.... you will be directed to the index page</h2>';
			
			// redirect to the home page
			header ( "REFRESH:3; url=index.php" );
		} else {
			$query = "SELECT * FROM publisher WHERE email = '$email' AND password = '$password'";
			
			$member_result = mysqli_query ( $conn, $query ) or die ( "cant get email and password from the user" . mysqli_error($conn));
			$member_row = mysqli_fetch_array ( $member_result );
			
			// if we find the email
			if (mysqli_num_rows ( $member_result ) == 1) {
				// set the session var for the user
				$_SESSION ['user'] = $member_row ['name'];
				$_SESSION ['user_id'] = $member_row ['id']; // this is for get the user_id
				$_SESSION ['user_type'] = "publisher"; // this is for get the user type
				
				echo '<h2>Thank you for login in.... you will be directed to the index page</h2>';
				
				// redirect to the home page
				header ( "REFRESH:3; url=index.php" );
			} else {
				echo '<h2>Invalid email or password .... try again</h2>';
				
				// redirect to the home page
				header ( "REFRESH:3; url=index.php" );
			}
		}
	}
}
?>

<?php include 'footer.php';?>