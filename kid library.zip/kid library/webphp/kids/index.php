<?php include 'header.php';?>

<p>&nbsp;</p>
<p>&nbsp;</p>

<p align="center">
	<img alt="" src="img/logo.jpg" width="30%">
</p>

<?php include 'footer.php';?>