<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
if (isset ( $_POST ['submit'] )) {
	$title = $_POST ['title'];
	
	// query to check if the catalog has recored before or not
	$title_query = mysqli_query($conn,  "SELECT title FROM catalog WHERE title = '$title'" ) or die ( 'error ' . mysql_error () );
	
	if (mysqli_num_rows ( $name_query ) != 0) {
		echo "<h3 style='text-align: center; padding-bottom: 10px; border-bottom: 1px solid #d9db5c'>This title has already registered before.... try another one</h3>";
		header ( "REFRESH:3; url=admin_add_catalog.php" );
	} else {
		// insert query for catalog
		$query = "INSERT INTO catalog
		(title)
		VALUES
		('$title')";
		
		$catalog_result = mysqli_query($conn,  $query ) or die ( "Can't add this catalog" . mysql_error () );
		
		// if there is affected rows in the database;
		if (mysqli_affected_rows ($conn) == 1) {
			echo "<h3>You have add catalog successfuly</h3>";
			
			// redirect to the home page
			echo '<meta http-equiv="refresh" content="3;url=admin_show_catalogs.php">';
		} else {
			echo "<h3>error in adding catalog </h3>";
			
			// redirect to the home page
			echo '<meta http-equiv="refresh" content="3;url=admin_show_catalogs.php">';
		}
	}
}
?>

<?php include 'footer.php';?>