<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
// delete the book
mysqli_query($conn,  "DELETE FROM book WHERE isbn = $_GET[isbn]" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysqli_affected_rows ($conn) == 1) {
	echo "<h3>Book Has been deleted successfuly ....</h3>";
	
	// redirect to the details page for the added book with the last inserted id
	echo '<meta http-equiv="refresh" content="3;url=admin_show_books.php">';
} else {
	echo "<h2>There is an error in deleting book</h2>";
	echo '<meta http-equiv="refresh" content="3;url=admin_show_books.php">';
}
?>

<?php include 'footer.php';?>