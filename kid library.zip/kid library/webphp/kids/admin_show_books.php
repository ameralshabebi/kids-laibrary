<?php include 'header.php';?>

<style>
td {
	text-align: center;
	padding: 5px;
}

th {
	background-color: #eee;
	padding: 10px;
}
</style>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<h2>Publishers Books</h2>
<?php
// get all information for the books
$books_query = "SELECT book.*, book.id AS book_id, catalog.title AS cat_title, publisher.id, publisher.name AS username FROM book LEFT JOIN publisher ON book.publisher_id = publisher.id LEFT JOIN catalog ON catalog.id = book.cat_id";

$books_result = mysqli_query ( $conn, $books_query ) or die ( 'error books : ' . mysqli_error ($conn) );
?>
<div class="post">
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<th>ISBN</th>
			<th>Title</th>
			<th>Author</th>
			<th>Pages</th>
			<th>Catalog</th>
			<th>Publisher</th>
			<th>Age</th>
			<th>Action</th>
		</tr>
		<?php while ($book_row = mysqli_fetch_array($books_result)) { ?>
		<tr>
			<td><?php echo $book_row['isbn']?></td>
			<td><?php echo $book_row['title'];?></td>
			<td><?php echo $book_row['author']?></td>
			<td><?php echo $book_row['pages'];?></td>
			<td><?php echo $book_row['cat_title'];?></td>
			<td><?php echo $book_row['username'];?></td>
			<td><?php echo $book_row['age'];?></td>
			<td><a href="#"
				onclick="if(window.confirm('Are You sure to delete the book ?')) window.location='admin_delete_book.php?isbn=<?php echo $book_row['isbn']?>'">Delete</a>
				| <a href="books/<?php echo $book_row['file'];?>" target="_blank">PDF
					File</a> | <a href="books/<?php echo $book_row['file_audio'];?>"
				target="_blank">Audio File</a>
			<?php
			// check the status
			if ($book_row ['status'] == "Not Verified") {
				?>
				| <a href="#"
				onclick="if(window.confirm('Are You sure to Verifiy the book ?')) window.location='admin_verify_book.php?isbn=<?php echo $book_row['isbn']?>'">Verify</a>
			<?php } ?>
			
			</td>
		</tr>
		<?php }?>
		<tr>
			<td colspan="8"><p>&nbsp;</p></td>
		</tr>
	</table>
</div>

<?php include 'footer.php';?>