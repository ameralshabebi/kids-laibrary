<?php include 'header.php';?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	header ( "Location: index.php" );
}
?>

<?php
// get all information for the users
$users_query = "SELECT * FROM user";
$users_result = mysqli_query($conn,  $users_query ) or die ( 'error : ' . mysql_error () );
?>

<h2>All Users</h2>
<div class="post">
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Email</th>
			<th>Mobile</th>
			<th>Age</th>
			<th>Progress</th>
			<th>Action</th>
		</tr>
		<?php while ($user_row = mysqli_fetch_array($users_result)) { ?>
		<tr style="text-align: center;">
			<td><?php echo $user_row['id']?></td>
			<td><?php echo $user_row['name'];?></td>
			<td><?php echo $user_row['email'];?></td>
			<td><?php echo $user_row['mobile'];?></td>
			<td><?php echo $user_row['age'];?></td>
			<td><?php echo $user_row['progress'];?></td>
			<td><a href="admin_edit_user.php?id=<?php echo $user_row['id']?>">Edit</a>
				&nbsp;&nbsp;&nbsp;&nbsp; <a href="#"
				onclick="if(window.confirm('Are You sure to delete the user ?')) window.location='admin_delete_user.php?id=<?php echo $user_row['id']?>'">Delete</a>
			</td>
		</tr>
		<?php }?>
		<tr>
			<th colspan="7" style="text-align: center;"><a
				href="admin_add_user.php">Add New User</a></th>
		</tr>
	</table>
</div>
<?php include 'footer.php';?>