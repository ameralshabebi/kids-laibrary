<?php include 'header.php'; ?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<?php
// if there is post from the catalog to edit the profile
if (isset ( $_POST ['submit'] )) {
	$title = $_POST ['title'];
	$id = $_POST ['id'];
	
	$update_query = "UPDATE catalog
								SET title = '$title'
								WHERE id = $id";
	
	$update_catalog_result = mysqli_query($conn,  $update_query ) or die ( "Can't update this catalog" . mysql_error () );
	
	// if there is affected rows in the database;
	if (mysqli_affected_rows ($conn) == 1) {
		
		echo "<h3>Thank you for edit the catalog  ....</h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3;url=admin_show_catalogs.php">';
	} else {
		echo "<h3>No update Happend in the catalog  data .... </h3>";
		
		// redirect to the home page
		echo '<meta http-equiv="refresh" content="3;url=admin_show_catalogs.php">';
	}
}  // end if isset($_POST['edit_profile'])

else { // if there is no post to edit the profile; show the reset of the page
       // check for the catalog is login or not
       // if he not logged in ; redirect to the index page
	if (! isset ( $_SESSION ['catalog'] ) || $_SESSION ['catalog'] == "") {
		echo '<meta http-equiv="refresh" content="3;url=index.php">';
	}
}
?>

<?php include 'footer.php'; ?>