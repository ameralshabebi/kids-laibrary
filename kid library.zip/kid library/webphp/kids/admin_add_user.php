<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "admin") {
	echo '<meta http-equiv="refresh" content="3;url=index.php">';
}
?>

<h2>Add New User</h2>

<p>&nbsp;</p>

<div class="row">
	<div
		class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-default">
			<div class="panel-body">
				<form name="my_form" role="form" action="admin_add_user_check.php"
					method="post">
					<fieldset>
						<div class="form-group">
							<strong>Age</strong> <input type="number" name="age" min="1"
								max="12" required class="form-control">
						</div>
						<div class="form-group">
							<strong>mobile</strong> <input type="text" name="mobile" required
								pattern="[0-9]{10}" class="form-control">
						</div>
						<div class="form-group">
							<strong>User Name</strong> <input type="text" name="name"
								required class="form-control">
						</div>

						<div class="form-group">
							<strong>Password</strong> <input type="password" name="password"
								required class="form-control">
						</div>
						<div class="form-group">
							<strong>Email</strong> <input type="email" name="email" required
								class="form-control">
						</div>

						<div align="center">
							<input type="submit" name="submit" class="btn btn-primary"
								value="Add" />
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.col-->
</div>
<?php include 'footer.php';?>