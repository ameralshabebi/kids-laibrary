<?php include 'header.php';?>

<?php
// start the session
session_start();

// destroy the sessions
session_destroy();

echo "<h3>You have been logged out.... you will be redirected to the index page</h3>";

// redirect to the index.php
echo '<meta http-equiv="refresh" content="3;url=index.php">';
?>


<?php include 'footer.php';?>