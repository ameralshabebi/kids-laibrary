package com.example.kids;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserShowSearchBooksActivity extends Activity {

    // Progress Dialog
    private ProgressDialog pDialog;

    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();

    ArrayList<Books> booksList;

    BookAdapter adapter;

    // url to get all items list
    private static String url_books = "http://.000webhostapp.com/user_search_books.php";

    // JSON Node titles
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private static final String TAG_BOOKS = "books";

    private static final String TAG_BOOKS_TITLE = "book_title";
    private static final String TAG_BOOK_ID = "book_id";
    private static final String TAG_BOOK_IMAGE = "book_file";

    ListView book_list;

    // books JSONArray
    JSONArray books = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_show_search_books);

        book_list = (ListView) findViewById(R.id.user_search_books_lst);

        // Hashmap for ListView
        booksList = new ArrayList<Books>();

        // make a controller object to store user information in it
//        Controller aController = (Controller) getApplicationContext();

        new LoadAllBooks().execute();
    }

    /**
     * Background Async Task to Load all items by making HTTP Request
     */
    class LoadAllBooks extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread Show Progress Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UserShowSearchBooksActivity.this);
            pDialog.setMessage("جاري ارجاع الكتب");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        /**
         * getting All books from url
         */
        protected String doInBackground(String... args) {

//            String cat_id = getIntent().getExtras().getString("catalog_id");

            Controller aController = (Controller) getApplicationContext();

            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("search_txt", getIntent().getStringExtra("search_txt")));

            // getting JSON string from URL
            JSONObject json = JSONParser.makeHttpRequest(url_books, "GET",
                    params);

            // Check your log cat for JSON reponse
            Log.d("All books info : ", json.toString());

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // items found
                    // Getting Array of items
                    books = json.getJSONArray(TAG_BOOKS);

                    // looping through All items
                    for (int i = 0; i < books.length(); i++) {
                        JSONObject c = books.getJSONObject(i);

                        // Storing each json item in variable
                        String book_title = c.getString(TAG_BOOKS_TITLE);
                        String book_id = c.getString(TAG_BOOK_ID);
                        String book_image = c.getString(TAG_BOOK_IMAGE);

                        Books book = new Books();

                        book.setName(book_title);
                        book.setId(book_id);
                        book.setImage("http://.000webhostapp.com/no_image.png");
                        booksList.add(book);
                    }
                } else {
                    return json.getString(TAG_MESSAGE);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * After completing background task Dismiss the progress dialog *
         */
        protected void onPostExecute(String file_url) {
            // dismiss the dialog after getting all books
            pDialog.dismiss();

            // Toast.makeText(getApplicationContext(), String.valueOf(dist[0]),
            // Toast.LENGTH_LONG).show();

            adapter = new BookAdapter(UserShowSearchBooksActivity.this, R.layout.row,
                    booksList);

            book_list.setAdapter(adapter);

            book_list
                    .setOnItemClickListener(new AdapterView.OnItemClickListener() {

                        @Override
                        public void onItemClick(AdapterView<?> arg0, View arg1,
                                                int position, long id) {
                            // TODO Auto-generated method stub
                            // Toast.makeText(getApplicationContext(),
                            // booksList.get(position).getName(),
                            // Toast.LENGTH_LONG).show();

                            // on selecting single book
                            // open the book details intent
                            book_list
                                    .setOnItemClickListener(new AdapterView.OnItemClickListener() {

                                        @Override
                                        public void onItemClick(
                                                AdapterView<?> parent,
                                                View view, int position, long id) {

                                            String book_id = ((TextView) view
                                                    .findViewById(R.id.tvId))
                                                    .getText().toString();

                                            // book details
                                            Intent book_detail = new Intent(
                                                    UserShowSearchBooksActivity.this,
                                                    UserShowSearchBookActivity.class);

                                            // sending title to next activity
                                            book_detail.putExtra(
                                                    "book_id", book_id);
                                            finish();
                                            startActivity(book_detail);
                                        }
                                    });
                        }
                    });
        }
    }
}