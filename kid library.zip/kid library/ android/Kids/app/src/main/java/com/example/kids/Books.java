package com.example.kids;

public class Books {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return title;
    }

    public void setName(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    private String id;
    private String title;
    private String image;

    public Books() {
        // TODO Auto-generated constructor stub
    }

    public Books(String id, String title, String image) {
        super();
        this.id = id;
        this.title = title;
        this.image = image;
    }
}
