package com.example.kids;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserShowSearchBookActivity extends Activity {

    // Progress Dialog
    private ProgressDialog pDialog;

    // JSON parser class
    JSONParser jsonParser = new JSONParser();

    // the url for the book page on the server
    private static final String BOOK_URL = "http://.000webhostapp.com/user_book_info.php";

    // JSON element ids from repsonse of php script:
    private static final String TAG_TITLE = "book_title";
    private static final String TAG_AUTHOR = "book_author";
    private static final String TAG_PAGES = "book_pages";
    private static final String TAG_FILE = "book_file";
    private static final String TAG_AUDIO_FILE = "book_audio_file";
    private static final String TAG_ISBN = "book_isbn";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    TextView book_isbn;
    TextView book_title;
    TextView book_author;
    TextView book_pages;

    int pages;
    String title;
    String isbn;
    String author;
    String file;
    String audio_file;

    String book_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_show_search_book);

        book_id = getIntent().getStringExtra("book_id");

        book_isbn = (TextView) findViewById(R.id.order_book_isbn_txt);
        book_title = (TextView) findViewById(R.id.order_book_title_txt);
        book_author = (TextView) findViewById(R.id.order_book_author_txt);
        book_pages = (TextView) findViewById(R.id.order_book_pages_txt);

        // connect to the server and get the book details
        new AttemptGetBook().execute();

        Button user_search_read_book_btn = (Button) findViewById(R.id.user_search_read_book_btn);
        user_search_read_book_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserShowSearchBookActivity.this, UserReadBookActivity.class);
                intent.putExtra("book_id", book_id);
                intent.putExtra("book_file", file);
                intent.putExtra("book_file_audio", audio_file);
                startActivity(intent);
            }
        });
    }

    // AsyncTask is a seperate thread than the thread that runs the GUI
    // Any type of networking should be done with asynctask.
    class AttemptGetBook extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UserShowSearchBookActivity.this);
            pDialog.setMessage("جاري ارجاع معلومات الكتاب");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... args) {
            // Check for success tag
            int success;

            try {

                // get the book title from the prev intent
                Intent intent = getIntent();
                String book_id = intent.getStringExtra("book_id");

                // Building Parameters
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("book_id", book_id));

                // getting book details by making HTTP request
                JSONObject json = JSONParser.makeHttpRequest(BOOK_URL, "POST",
                        params);

                // json success tag
                success = json.getInt(TAG_SUCCESS);

                if (success == 1) {

                    Log.d("All Book information : ", json.toString());

                    // set the vars to the returned server data
                    pages = json.getInt(TAG_PAGES);
                    author = json.getString(TAG_AUTHOR);
                    title = json.getString(TAG_TITLE);
                    file = json.getString(TAG_FILE);
                    audio_file = json.getString(TAG_AUDIO_FILE);
                    isbn = json.getString(TAG_ISBN);

                    return json.getString(TAG_MESSAGE);

                } else {
                    return json.getString(TAG_MESSAGE);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * After completing background task Dismiss the progress dialog
         **/

        protected void onPostExecute(String file_url) {
            // dismiss the dialog once book favorited
            pDialog.dismiss();

            // set the book texts with the data from server
            book_pages.setText(String.valueOf(pages));
            book_author.setText(author);
            book_title.setText(title);
            book_isbn.setText(isbn);
        }
    }
}
