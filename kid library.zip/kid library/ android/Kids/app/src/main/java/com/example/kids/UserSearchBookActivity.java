package com.example.kids;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserSearchBookActivity extends Activity {

    Button user_search_book_btn;
    EditText book_search_txt;

    int errors;

//    String catalog_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_search_book);

        errors = 0;

        // buttons
        user_search_book_btn = (Button) findViewById(R.id.user_search_book_btn);

        // edit texts
        book_search_txt = (EditText) findViewById(R.id.book_search_txt);

//        Intent intent = getIntent();

        user_search_book_btn
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        // validate the title
                        if (book_search_txt.getText().toString().length() == 0) {
                            errors += 1;
                            book_search_txt.setError("Enter Valid Content");
                        } else {
                            // make new activity
                            Intent i = new Intent(UserSearchBookActivity.this, UserShowSearchBooksActivity.class);
                            i.putExtra("search_txt", book_search_txt.getText().toString());
                            startActivity(i);
                        }
                    }
                });
    }
}