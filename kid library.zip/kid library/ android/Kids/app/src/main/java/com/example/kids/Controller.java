package com.example.kids;

import android.app.Application;

public class Controller extends Application {

    // user information
    private int id;
    private String name;
    private String email;
    private String password;
    private String mobile;
    private String age;
    private String progress;
    private String type;

    private String book_name;
    private String book_pages;
    private String book_isbn;
    private String book_author;
    private String filename;
    private String filepath;


    public void setBookName(String name) {
        this.book_name = name;
    }

    public String getBookName() {
        return book_name;
    }

    public void setBookPages(String pages) {
        this.book_pages = pages;
    }

    public String getBookPages() {
        return book_pages;
    }

    public void setBookIsbn(String isbn) {
        this.book_isbn = isbn;
    }

    public String getBookIsbn() {
        return book_isbn;
    }

    public void setBookAuthor(String author) {
        this.book_author = author;
    }

    public String getBookAuthor() {
        return book_author;
    }


    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMobile() {
        return mobile;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getAge() {
        return age;
    }


    public void setProgress(String progress) {
        this.progress = progress;
    }

    public String getProgress() {
        return progress;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }


    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getFilepath() {
        return filepath;
    }
}