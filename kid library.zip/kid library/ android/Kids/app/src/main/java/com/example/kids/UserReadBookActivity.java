package com.example.kids;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class UserReadBookActivity extends Activity {

    // Progress Dialog
    private ProgressDialog pDialog;

    // JSON parser class
    JSONParser jsonParser = new JSONParser();

    // the url for the book page on the server
    private static final String BOOK_URL = "http://.000webhostapp.com/user_read_book.php";

    WebView webView;

    String book_id;
    String book_file;
    String book_file_audio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_read_book);

        // make a controller object to store books in it
        final Controller aController = (Controller) getApplicationContext();

        // buy buttons
        Button user_finish_book_btn = (Button) findViewById(R.id.user_finish_book_btn);
        Button user_voice_book_btn = (Button) findViewById(R.id.user_voice_book_btn);

        book_id = getIntent().getStringExtra("book_id");
        book_file_audio = getIntent().getStringExtra("book_file_audio");
        book_file = getIntent().getStringExtra("book_file");

        // get the file id from the prev intent
//        Intent intent = getIntent();

        webView = (WebView) findViewById(R.id.read_my_webview);
        webView.setWebViewClient(new WebViewClient());
//        webView.addView(webView.se getZoomControls());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.loadUrl("http://docs.google.com/gview?embedded=true&url=http://.000webhostapp.com/web/books/" + book_file);

        // check the type of the user to listen the voice or add voice
        user_voice_book_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (book_file_audio != "") {
                    webView.loadUrl("http://.000webhostapp.com/web/books/" + book_file_audio);
                }
            }
        });

        // read book
        user_finish_book_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                new AttemptFinish().execute();
            }
        });
    }

    // class
    class AttemptFinish extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(UserReadBookActivity.this);
            pDialog.setMessage("جاري التحديث");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub

            // Check for success tag
            int success;
//            int user_id = aController.getId();

            try {
                Intent intent = getIntent();
                String book_id = intent.getStringExtra("book_id");

                Controller aController = (Controller) getApplicationContext();

                // Building Parameters
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("user_id", String.valueOf(aController.getId())));
                params.add(new BasicNameValuePair("book_id", book_id));

                // getting user details by making HTTP request
                JSONObject json = JSONParser.makeHttpRequest(BOOK_URL, "POST",
                        params);

                // json success tag
                success = json.getInt("success");

                if (success == 1) {
                    aController.setProgress(String.valueOf(json.getInt("progress")));
                }

                // return the message from the server
                return json.getString("message");

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        // After completing background task Dismiss the progress dialog
        protected void onPostExecute(String message) {
            // dismiss the dialog once book favorited
            pDialog.dismiss();

            // show the returned message from the server
            Toast.makeText(UserReadBookActivity.this, message,
                    Toast.LENGTH_LONG).show();

            // go to the Menu activity
            Intent user_menu = new Intent(UserReadBookActivity.this, UserMenuActivity.class);
            startActivity(user_menu);
        }
    }
}