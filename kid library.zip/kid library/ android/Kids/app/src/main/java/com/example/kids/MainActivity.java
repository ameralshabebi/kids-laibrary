package com.example.kids;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button child_btn = (Button) findViewById(R.id.child_btn);
        Button volunteer_btn = (Button) findViewById(R.id.volunteer_btn);

        child_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent login = new Intent(MainActivity.this,
                        UserLoginActivity.class);
                startActivity(login);
            }
        });

        volunteer_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent login = new Intent(MainActivity.this,
                        VolunteerLoginActivity.class);
                startActivity(login);
            }
        });

    }

    // if the user click the back button
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}
