package com.example.kids;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class UserMenuActivity extends Activity {

    Button user_menu_search_btn, user_menu_show_books_btn;
    Button user_menu_profile_btn, user_menu_logout_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_menu);

        user_menu_logout_btn = (Button) findViewById(R.id.user_menu_logout_btn);
        user_menu_show_books_btn = (Button) findViewById(R.id.user_menu_show_books_btn);
        user_menu_search_btn = (Button) findViewById(R.id.user_menu_search_btn);
        user_menu_profile_btn = (Button) findViewById(R.id.user_menu_profile_btn);

        user_menu_logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(UserMenuActivity.this, UserLoginActivity.class);
                startActivity(in);
            }
        });


        // check the user type
        Controller aController = (Controller) getApplicationContext();
        String type = aController.getType();

        if (type == "user") {
            user_menu_profile_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = new Intent(UserMenuActivity.this, UserProfileActivity.class);
                    startActivity(in);
                }
            });
        } else if (type == "volunteer") {
            user_menu_profile_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = new Intent(UserMenuActivity.this, VolunteerProfileActivity.class);
                    startActivity(in);
                }
            });
        }


        user_menu_search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(UserMenuActivity.this, UserSearchBookActivity.class);
                startActivity(in);
            }
        });

        user_menu_show_books_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(UserMenuActivity.this, CatalogActivity.class);
                startActivity(in);
            }
        });
    }

    // if the user click the back button
    // do nothing
    @Override
    public void onBackPressed() {

    }
}
