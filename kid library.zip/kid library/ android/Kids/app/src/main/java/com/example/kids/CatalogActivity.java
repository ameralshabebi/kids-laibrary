package com.example.kids;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CatalogActivity extends Activity {

    ListView catalogs_lst;

    // Progress Dialog
    private ProgressDialog pDialog;

    // Creating JSON Parser object
    JSONParser jParser = new JSONParser();

    ArrayList<HashMap<String, String>> catalogsList;

    // url to get all catalogs list
    private static String url_catalogs = "http://.000webhostapp.com/user_catalogs.php";

    // JSON Node titles
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private static final String TAG_ITEMS = "catalogs";

    private static final String TAG_TITLE = "catalog_title";
    private static final String TAG_ID = "catalog_id";

    ListView catalogs_list;

    // catalogs JSONArray
    JSONArray catalogs = null;

    TextView mSearchText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);

        // define list
        catalogs_lst = (ListView) findViewById(R.id.catalogs_lst);

        // Hashmap for ListView
        catalogsList = new ArrayList<HashMap<String, String>>();

        // Loading catalogs in Background Thread
        new LoadAllcatalogs().execute();
    }

    /**
     * Background Async Task to Load all catalogs by making HTTP Request
     */
    class LoadAllcatalogs extends AsyncTask<String, String, String> {

        /**
         * Before starting background thread Show Progress Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(CatalogActivity.this);
            pDialog.setMessage("جاري ارجاع التصنيفات");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(false);
            pDialog.show();
        }

        /**
         * getting All books from url
         */
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("test", "test"));

            // getting JSON string from URL
            JSONObject json = JSONParser.makeHttpRequest(url_catalogs, "POST",
                    params);

            // Check your log cat for JSON reponse
            // Log.d("All catalog info : ", json.toString());

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // catalogs found
                    // Getting Array of catalogs
                    catalogs = json.getJSONArray(TAG_ITEMS);

                    // looping through All catalogs
                    for (int i = 0; i < catalogs.length(); i++) {
                        JSONObject c = catalogs.getJSONObject(i);

                        // Storing each json catalog in variable
                        String title = c.getString(TAG_TITLE);
                        String id = c.getString(TAG_ID);

                        // creating new HashMap
                        HashMap<String, String> map = new HashMap<String, String>();

                        // adding each child node to HashMap key => value
                        map.put(TAG_TITLE, title);
                        map.put(TAG_ID, id);

                        // adding HashList to ArrayList
                        catalogsList.add(map);
                    }
                } else {
                    return json.getString(TAG_MESSAGE);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        /**
         * After completing background task Dismiss the progress dialog
         **/
        protected void onPostExecute(String file_url) {
            // dismiss the dialog after getting all books
            pDialog.dismiss();

            // make list adapter to fill the catalog list
            ListAdapter adapter = new SimpleAdapter(CatalogActivity.this,
                    catalogsList, R.layout.catalogs_list, new String[]{
                    TAG_TITLE, TAG_ID}, new int[]{R.id.catalog_title,
                    R.id.catalog_id});

            // Get listview
            catalogs_list = (ListView) findViewById(R.id.catalogs_lst);

            catalogs_list.setAdapter(adapter);

            catalogs_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    // getting values from selected ListItem
                    String catalog_id = ((TextView) view.findViewById(R.id.catalog_id)).getText().toString();
                    // open the items activity
                    Intent catalog_info = new Intent(CatalogActivity.this, UserShowBooksActivity.class);

                    // pass the student_id to the next intent
                    catalog_info.putExtra("catalog_id", catalog_id);

                    startActivity(catalog_info);
                }
            });
        }
    }
}
